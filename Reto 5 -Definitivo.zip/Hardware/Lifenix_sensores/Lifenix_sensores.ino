// ===== PROGRAMA Lifenix - Bloque 1 completo: los 3 sensores juntos =====
// Cada 1 segundo escribe una línea JSON con pulso, spo2, temperatura y movimiento
// (formato acordado en el archivo 03). En el Bloque 2 esta línea se enviará por WiFi.

#include <Wire.h>                 // Librería para comunicarse por I2C (cables SDA y SCL)
#include "MAX30105.h"             // Librería de SparkFun para el MAX30102 (pulso y oxígeno)
#include "spo2_algorithm.h"       // Fórmula de la librería: la usamos SOLO para el oxígeno
#include <Adafruit_MLX90614.h>    // Librería de Adafruit para el MLX90614 (temperatura)

MAX30105 sensorPulso;             // Objeto que representa al MAX30102
Adafruit_MLX90614 sensorTemp;     // Objeto que representa al MLX90614

// ======================= MAX30102: pulso y oxígeno =======================
const int MUESTRAS = 100;               // Lecturas que juntamos para calcular pulso y oxígeno (4 segundos)
const int LECTURAS_POR_SEGUNDO = 25;    // El sensor entrega 25 lecturas por segundo
const int DISTANCIA_MIN = 10;           // Mínimo de lecturas entre dos latidos (0,4 s)
const float MARGEN = 0.15;              // Líneas "arriba" y "abajo": 15 % de la altura de la onda

uint32_t bufferIR[MUESTRAS];            // Las 100 lecturas de luz infrarroja
uint32_t bufferRojo[MUESTRAS];          // Las 100 lecturas de luz roja

const int PULSO_MIN = 40;               // Pulso mínimo aceptado (lpm)
const int PULSO_MAX = 150;              // Pulso máximo aceptado (lpm)
const int SPO2_MIN  = 80;               // Oxígeno mínimo aceptado (%)

const int N = 4;                        // Cantidad de lecturas buenas que promediamos
int historialPulso[N] = {0};            // Últimos 4 pulsos buenos (0 = vacío)
int historialSpo2[N]  = {0};            // Últimos 4 oxígenos buenos (0 = vacío)
int posicion = 0;                       // Casilla donde va la siguiente lectura buena

int pulsoActual = 0;                    // Último pulso calculado (0 = sin dato)
int spo2Actual  = 0;                    // Último oxígeno calculado (0 = sin dato)

// ======================= MPU6050: movimiento (chip clon, sin librería) =======================
const byte DIRECCION_MPU = 0x68;        // Dirección I2C del sensor de movimiento
const float LSB_POR_G = 4096.0;         // Con rango ±8 g: 4096 unidades por cada 1 g

float sumaMovimiento = 0;               // Suma de los movimientos del último segundo
int contadorMovimiento = 0;             // Cuántos movimientos sumamos en el último segundo

// ---- Escribe un valor en un casillero (registro) del MPU6050 ----
void escribirRegistroMPU(byte registro, byte valor) {
  Wire.beginTransmission(DIRECCION_MPU);   // Empezamos a hablarle al sensor
  Wire.write(registro);                    // Casillero que queremos cambiar
  Wire.write(valor);                       // Valor que queremos poner
  Wire.endTransmission();                  // Terminamos el mensaje
}

// ---- Lee la aceleración y devuelve el "movimiento" en g (quieto ≈ 0) ----
float leerMovimiento() {
  Wire.beginTransmission(DIRECCION_MPU);   // Empezamos a hablarle al sensor
  Wire.write(0x3B);                        // Casillero donde empiezan los datos de aceleración
  Wire.endTransmission(false);             // Terminamos sin "colgar" la llamada
  Wire.requestFrom(DIRECCION_MPU, (byte)6);   // Pedimos 6 bytes (x, y, z)

  int16_t crudoX = (Wire.read() << 8) | Wire.read();  // Unimos los 2 bytes de x
  int16_t crudoY = (Wire.read() << 8) | Wire.read();  // Unimos los 2 bytes de y
  int16_t crudoZ = (Wire.read() << 8) | Wire.read();  // Unimos los 2 bytes de z

  float ax = crudoX / LSB_POR_G;           // x en g
  float ay = crudoY / LSB_POR_G;           // y en g
  float az = crudoZ / LSB_POR_G;           // z en g

  float total = sqrt(ax * ax + ay * ay + az * az);  // Las 3 direcciones en un solo valor
  return fabs(total - 1.0);                // Quitamos la gravedad: quieto ≈ 0
}

// ---- Calcula el pulso contando las caídas GRANDES de la onda (función ya probada) ----
int calcularPulso(long promedio) {
  long maximo = 0;                         // Valor más alto de la onda
  long minimo = 999999;                    // Valor más bajo de la onda
  for (int i = 0; i < MUESTRAS; i++) {     // Recorremos las 100 lecturas
    long valor = (long)bufferIR[i];        // Tomamos cada una
    if (valor > maximo) maximo = valor;    // Guardamos la más alta
    if (valor < minimo) minimo = valor;    // Guardamos la más baja
  }

  long altura = maximo - minimo;                          // Altura de la onda
  long lineaArriba = promedio + (long)(altura * MARGEN);  // Línea por ENCIMA del promedio
  long lineaAbajo  = promedio - (long)(altura * MARGEN);  // Línea por DEBAJO del promedio

  bool estuvoArriba = false;               // ¿La onda ya subió? (lista para un latido)
  int primerLatido = -1;                   // Posición del primer latido
  int ultimoLatido = -100;                 // Posición del último latido
  int latidos = 0;                         // Cantidad de latidos

  for (int i = 0; i < MUESTRAS; i++) {     // Recorremos las 100 lecturas
    long valor = (long)bufferIR[i];        // Lectura actual
    if (valor > lineaArriba) estuvoArriba = true;   // Subió claramente: lista para un latido
    if (estuvoArriba && valor < lineaAbajo) {       // Ya había subido y ahora cayó claramente...
      if ((i - ultimoLatido) >= DISTANCIA_MIN) {    // ...y pasó suficiente tiempo...
        if (primerLatido < 0) primerLatido = i;     // ...anotamos el primero
        ultimoLatido = i;                           // ...anotamos este latido
        latidos++;                                  // ...y lo contamos
      }
      estuvoArriba = false;                // Debe volver a subir antes del próximo latido
    }
  }

  if (latidos < 2) return 0;               // Con menos de 2 latidos no se puede medir
  float lecturasPorLatido = (float)(ultimoLatido - primerLatido) / (latidos - 1);  // Distancia promedio
  return (int)(60.0 * LECTURAS_POR_SEGUNDO / lecturasPorLatido);  // Latidos por minuto
}

// ---- Con las 100 lecturas, actualiza pulsoActual y spo2Actual ----
void actualizarPulsoYOxigeno() {
  long sumaIR = 0;                         // Suma de la luz infrarroja
  for (int i = 0; i < MUESTRAS; i++) sumaIR += bufferIR[i];  // Sumamos las 100 lecturas
  long promedioIR = sumaIR / MUESTRAS;     // Promedio de luz infrarroja

  if (promedioIR < 50000) {                // Si no hay dedo...
    for (int k = 0; k < N; k++) {          // ...borramos la memoria
      historialPulso[k] = 0;
      historialSpo2[k]  = 0;
    }
    pulsoActual = 0;                       // ...y enviamos 0 (sin dato)
    spo2Actual  = 0;
    return;                                // Salimos sin calcular
  }

  int pulso = calcularPulso(promedioIR);   // NUESTRO cálculo del pulso

  int32_t spo2, pulsoLib;                  // Variables que pide la fórmula de la librería
  int8_t spo2Valido, pulsoLibValido;       // Validez de cada dato
  maxim_heart_rate_and_oxygen_saturation(bufferIR, MUESTRAS, bufferRojo,
                                         &spo2, &spo2Valido, &pulsoLib, &pulsoLibValido);  // Solo usamos spo2

  bool esBueno = (pulso >= PULSO_MIN) && (pulso <= PULSO_MAX) &&   // Pulso razonable...
                 (spo2Valido == 1) && (spo2 >= SPO2_MIN) && (spo2 <= 100);  // ...y oxígeno razonable

  if (esBueno) {                           // Si pasó el filtro...
    historialPulso[posicion] = pulso;      // ...guardamos el pulso
    historialSpo2[posicion]  = spo2;       // ...guardamos el oxígeno
    posicion = (posicion + 1) % N;         // ...y avanzamos de casilla
  }

  int sumaP = 0, sumaS = 0, cantidad = 0;  // Sumas y cantidad de lecturas buenas
  for (int k = 0; k < N; k++) {            // Revisamos las 4 casillas
    if (historialPulso[k] > 0) {           // Si tiene dato...
      sumaP += historialPulso[k];          // ...sumamos pulso
      sumaS += historialSpo2[k];           // ...sumamos oxígeno
      cantidad++;                          // ...y contamos
    }
  }

  if (cantidad > 0) {                      // Si hay al menos una lectura buena...
    pulsoActual = sumaP / cantidad;        // ...el pulso es el promedio
    spo2Actual  = sumaS / cantidad;        // ...el oxígeno es el promedio
  }                                        // (si no hay, se mantiene el último valor)
}

// ---- Lee la temperatura y escribe la línea JSON con los 4 datos ----
void escribirLineaJSON() {
  float temperatura = sensorTemp.readObjectTempC();       // Temperatura de la piel (°C)
  float movimiento = (contadorMovimiento > 0) ? sumaMovimiento / contadorMovimiento : 0;  // Promedio del segundo
  sumaMovimiento = 0;                      // Reiniciamos la suma para el próximo segundo
  contadorMovimiento = 0;                  // Reiniciamos el contador

  Serial.print("{\"pulso\":");             // {"pulso":
  Serial.print(pulsoActual);               // valor del pulso
  Serial.print(",\"spo2\":");              // ,"spo2":
  Serial.print(spo2Actual);                // valor del oxígeno
  Serial.print(",\"temperatura\":");       // ,"temperatura":
  Serial.print(temperatura, 1);            // temperatura con 1 decimal
  Serial.print(",\"movimiento\":");        // ,"movimiento":
  Serial.print(movimiento, 2);             // movimiento con 2 decimales
  Serial.println("}");                     // } y salto de línea
}

void setup() {                             // Se ejecuta UNA vez al encender
  Serial.begin(115200);                    // Comunicación con la laptop
  Wire.begin(21, 22);                      // I2C: SDA en GPIO 21 y SCL en GPIO 22 (archivo 04)

  if (!sensorPulso.begin(Wire, I2C_SPEED_STANDARD)) {   // Buscamos el MAX30102 (a 100 kHz)
    Serial.println("ERROR: no se encontro el MAX30102. Revisa los cables.");
    while (1);
  }
  sensorPulso.setup(30, 4, 2, 100, 411, 4096);  // Configuración ya probada (brillo 30)

  if (!sensorTemp.begin()) {               // Buscamos el MLX90614
    Serial.println("ERROR: no se encontro el MLX90614. Revisa los cables.");
    while (1);
  }

  Wire.beginTransmission(DIRECCION_MPU);   // Buscamos el MPU6050
  if (Wire.endTransmission() != 0) {
    Serial.println("ERROR: no se encontro el MPU6050. Revisa los cables.");
    while (1);
  }
  escribirRegistroMPU(0x6B, 0x00);         // Despertamos al MPU6050
  escribirRegistroMPU(0x1C, 0x10);         // Rango ±8 g
  escribirRegistroMPU(0x1A, 0x04);         // Filtro suave

  Wire.setClock(100000);                   // Aseguramos velocidad normal (100 kHz) para los 3 sensores
  Serial.println("Lifenix: 3 sensores listos. Coloca el dedo en el sensor de pulso.");
}

void loop() {                              // Se repite sin parar (cada vuelta dura 4 segundos)
  for (int i = 0; i < MUESTRAS; i++) {     // Juntamos 100 lecturas del MAX30102
    while (sensorPulso.available() == false) sensorPulso.check();  // Esperamos una lectura lista
    bufferRojo[i] = sensorPulso.getFIFORed();   // Lectura roja ya lista (sin saltarse lecturas)
    bufferIR[i]   = sensorPulso.getFIFOIR();    // Lectura infrarroja ya lista
    sensorPulso.nextSample();                   // Pasamos a la siguiente

    sumaMovimiento += leerMovimiento();    // Sumamos el movimiento de este instante
    contadorMovimiento++;                  // Y contamos una medición más

    if ((i + 1) % LECTURAS_POR_SEGUNDO == 0) {  // Cada 25 lecturas (= 1 segundo)...
      escribirLineaJSON();                 // ...escribimos la línea con los 4 datos
    }
  }

  actualizarPulsoYOxigeno();               // Con las 100 lecturas, recalculamos pulso y oxígeno
}