// ===== PROGRAMA Lifenix - Bloque 1: lectura del MAX30102 (pulso propio con conteo estricto) =====

#include <Wire.h>              // Librería para comunicarse por I2C (los cables SDA y SCL)
#include "MAX30105.h"          // Librería de SparkFun que controla el sensor (sirve también para el MAX30102)
#include "spo2_algorithm.h"    // Fórmula de la librería: la usamos SOLO para el oxígeno

MAX30105 sensor;               // Creamos un "objeto" llamado sensor que representa al MAX30102

const int MUESTRAS = 100;      // Cantidad de lecturas que juntamos antes de calcular (4 segundos)
const float LECTURAS_POR_SEG = 25.0;  // El sensor entrega 25 lecturas por segundo (100 por seg / promedio de 4)
const int DISTANCIA_MIN = 10;  // Mínimo de lecturas entre dos latidos (0,4 s) para no contar uno dos veces
const float MARGEN = 0.15;     // Tamaño de las líneas "arriba" y "abajo": 15 % de la altura de la onda

uint32_t bufferIR[MUESTRAS];   // Lista donde guardamos las 100 lecturas de luz infrarroja
uint32_t bufferRojo[MUESTRAS]; // Lista donde guardamos las 100 lecturas de luz roja

int32_t spo2;                  // Aquí la fórmula de la librería guardará el oxígeno (en %)
int8_t  spo2Valido;            // Vale 1 si el oxígeno es confiable, 0 si no
int32_t pulsoLibreria;         // Pulso de la librería (no lo usamos, pero la fórmula lo pide)
int8_t  pulsoLibreriaValido;   // Validez del pulso de la librería (tampoco lo usamos)

int latidosContados = 0;       // Cuántos latidos encontró la última medición (para el diagnóstico)

// ---- Límites del filtro: fuera de estos rangos, el dato se considera ruido ----
const int PULSO_MIN = 40;      // Pulso mínimo aceptado (lpm)
const int PULSO_MAX = 150;     // Pulso máximo aceptado (lpm)
const int SPO2_MIN  = 80;      // Oxígeno mínimo aceptado (%)

// ---- Memoria de las últimas 4 lecturas buenas, para promediar ----
const int N = 4;               // Cantidad de lecturas buenas que promediamos
int historialPulso[N] = {0};   // Últimos 4 pulsos buenos (0 = casilla vacía)
int historialSpo2[N]  = {0};   // Últimos 4 oxígenos buenos (0 = casilla vacía)
int posicion = 0;                // Casilla donde se guardará la siguiente lectura buena

// ---- Función que calcula el pulso contando solo las caídas GRANDES de la onda ----
int calcularPulso(long promedio) {             // Recibe el promedio de la onda y devuelve el pulso (0 si no pudo)
  long maximo = 0;                             // Aquí guardaremos el valor más alto de la onda
  long minimo = 999999;                        // Aquí guardaremos el valor más bajo de la onda
  for (int i = 0; i < MUESTRAS; i++) {         // Recorremos las 100 lecturas...
    long valor = (long)bufferIR[i];            // ...tomamos cada una...
    if (valor > maximo) maximo = valor;        // ...y si es la más alta hasta ahora, la guardamos
    if (valor < minimo) minimo = valor;        // ...y si es la más baja hasta ahora, la guardamos
  }

  long altura = maximo - minimo;               // Altura total de la onda (de lo más bajo a lo más alto)
  long lineaArriba = promedio + (long)(altura * MARGEN);  // Línea un poco por ENCIMA del promedio
  long lineaAbajo  = promedio - (long)(altura * MARGEN);  // Línea un poco por DEBAJO del promedio

  bool estuvoArriba = false;                   // ¿La onda ya pasó por la línea de arriba? (empieza en no)
  int primerLatido = -1;                       // Posición del primer latido encontrado (-1 = ninguno aún)
  int ultimoLatido = -100;                     // Posición del último latido encontrado
  int latidos = 0;                             // Cantidad de latidos contados

  for (int i = 0; i < MUESTRAS; i++) {         // Recorremos las 100 lecturas
    long valor = (long)bufferIR[i];            // Tomamos la lectura actual

    if (valor > lineaArriba) {                 // Si la onda está claramente ARRIBA...
      estuvoArriba = true;                     // ...anotamos que ya subió (está "lista" para un latido)
    }

    if (estuvoArriba && valor < lineaAbajo) {  // Si ya había subido y ahora cayó claramente ABAJO...
      if ((i - ultimoLatido) >= DISTANCIA_MIN) {  // ...y pasó suficiente tiempo desde el último latido...
        if (primerLatido < 0) primerLatido = i;   // ...si es el primero, anotamos dónde fue
        ultimoLatido = i;                         // ...anotamos dónde fue este latido
        latidos++;                                // ...y sumamos un latido
      }
      estuvoArriba = false;                    // En cualquier caso, debe volver a subir antes del próximo latido
    }
  }

  latidosContados = latidos;                   // Guardamos cuántos latidos hubo (para el diagnóstico)
  if (latidos < 2) return 0;                   // Con menos de 2 latidos no se puede medir el ritmo

  float lecturasPorLatido = (float)(ultimoLatido - primerLatido) / (latidos - 1);  // Distancia promedio entre latidos
  return (int)(60.0 * LECTURAS_POR_SEG / lecturasPorLatido);  // Convertimos a latidos por minuto
}

void setup() {                 // Esta parte se ejecuta UNA sola vez al encender el ESP32
  Serial.begin(115200);        // Abrimos la comunicación con la laptop a 115200 de velocidad
  Wire.begin(21, 22);          // Iniciamos el I2C: SDA en el GPIO 21 y SCL en el GPIO 22 (según el archivo 04)

  if (!sensor.begin(Wire, I2C_SPEED_FAST)) {   // Intentamos encontrar el sensor en el bus I2C
    Serial.println("ERROR: no se encontro el MAX30102. Revisa los cables.");  // Si no lo encuentra, avisamos
    while (1);                 // Nos quedamos detenidos aquí para no seguir con un error
  }

  Serial.println("MAX30102 detectado. Coloca el dedo sobre el sensor y no lo muevas...");  // Mensaje de éxito
  sensor.setup(30, 4, 2, 100, 411, 4096);  // Brillo 30 (para no saturar), promedio 4, rojo+IR, 100/s, ancho, rango
}

void loop() {                  // Esta parte se repite UNA Y OTRA VEZ sin parar
  unsigned long inicio = millis();              // Anotamos la hora (en milisegundos) antes de juntar lecturas

  for (int i = 0; i < MUESTRAS; i++) {          // Repetimos 100 veces para juntar las lecturas
    while (sensor.available() == false) {       // Mientras el sensor no tenga una lectura nueva lista...
      sensor.check();                           // ...le preguntamos si ya tiene datos
    }
        bufferRojo[i] = sensor.getFIFORed();        // Tomamos la lectura roja que YA está lista (sin esperar otra)
    bufferIR[i]   = sensor.getFIFOIR();         // Tomamos la lectura infrarroja que YA está lista (sin esperar otra)
    sensor.nextSample();                        // Pasamos a la siguiente lectura
  }

  unsigned long duracion = millis() - inicio;   // Cuántos milisegundos tardamos en juntar las 100 lecturas
  float velocidadReal = MUESTRAS * 1000.0 / duracion;  // Lecturas por segundo reales (debería ser cerca de 25)

  long sumaIR = 0;                              // Aquí sumaremos toda la luz infrarroja
  for (int i = 0; i < MUESTRAS; i++) {          // Recorremos las 100 lecturas...
    sumaIR += bufferIR[i];                      // ...y las vamos sumando
  }
  long promedioIR = sumaIR / MUESTRAS;          // Promedio de luz infrarroja

  if (promedioIR < 50000) {                     // Si el promedio es bajo, no hay dedo sobre el sensor
    for (int k = 0; k < N; k++) {               // Borramos la memoria de lecturas anteriores
      historialPulso[k] = 0;                    // ...del pulso
      historialSpo2[k]  = 0;                    // ...y del oxígeno
    }
    Serial.println("Sin dedo: coloca el dedo sobre el sensor");  // Avisamos al usuario
    return;                                     // Volvemos a empezar el loop sin calcular nada
  }

  int pulso = calcularPulso(promedioIR);        // NUESTRO cálculo del pulso (solo caídas grandes)

  // La fórmula de la librería calcula el oxígeno (también calcula un pulso, que ignoramos)
  maxim_heart_rate_and_oxygen_saturation(bufferIR, MUESTRAS, bufferRojo,
                                         &spo2, &spo2Valido, &pulsoLibreria, &pulsoLibreriaValido);

  // ---- DIAGNÓSTICO TEMPORAL (luego lo borraremos) ----
  Serial.print("DIAG -> lecturas/s: ");         // Texto de inicio
  Serial.print(velocidadReal, 1);               // Velocidad real del sensor (con 1 decimal)
  Serial.print(" | latidos en 4 s: ");          // Texto
  Serial.print(latidosContados);                // Cuántos latidos contó en esta medición
  Serial.print(" | pulso nuestro: ");           // Texto
  Serial.print(pulso);                          // Pulso calculado
  Serial.print(" | spo2: ");                    // Texto
  Serial.print(spo2);                           // Oxígeno de la librería
  Serial.print(" (valido ");                    // Texto
  Serial.print(spo2Valido);                     // 1 = confiable, 0 = no
  Serial.println(")");                          // Cerramos la línea

  bool esBueno = (pulso >= PULSO_MIN) && (pulso <= PULSO_MAX) &&  // El pulso está en un rango razonable...
                 (spo2Valido == 1) &&                             // ...el oxígeno es confiable...
                 (spo2 >= SPO2_MIN) && (spo2 <= 100);             // ...y está en un rango razonable

  if (esBueno) {                                // Si la lectura pasó el filtro...
    historialPulso[posicion] = pulso;           // ...guardamos el pulso en la memoria
    historialSpo2[posicion]  = spo2;            // ...guardamos el oxígeno en la memoria
    posicion = (posicion + 1) % N;              // Avanzamos a la siguiente casilla (después de la 3 vuelve a la 0)
  }

  int sumaPulso = 0;                            // Suma de los pulsos buenos guardados
  int sumaSpo2  = 0;                            // Suma de los oxígenos buenos guardados
  int cantidad  = 0;                            // Cuántas lecturas buenas hay en la memoria
  for (int k = 0; k < N; k++) {                 // Revisamos las 4 casillas
    if (historialPulso[k] > 0) {                // Si la casilla tiene un dato...
      sumaPulso += historialPulso[k];           // ...sumamos su pulso
      sumaSpo2  += historialSpo2[k];            // ...sumamos su oxígeno
      cantidad++;                               // ...y contamos una lectura más
    }
  }

  if (cantidad == 0) {                          // Si todavía no hay ninguna lectura buena...
    Serial.println("Midiendo... manten el dedo quieto");  // ...pedimos paciencia
    return;                                     // Y volvemos a empezar el loop
  }

  Serial.print("Pulso: ");                      // Escribimos el texto "Pulso: "
  Serial.print(sumaPulso / cantidad);           // PROMEDIO de los pulsos buenos
  Serial.print(" lpm  |  SpO2: ");              // lpm = latidos por minuto
  Serial.print(sumaSpo2 / cantidad);            // PROMEDIO de los oxígenos buenos
  Serial.print(" %");                           // Símbolo de porcentaje
  if (!esBueno) Serial.print("  (lectura con ruido descartada)");  // Avisamos si la última se descartó
  Serial.println();                             // Terminamos la línea
}