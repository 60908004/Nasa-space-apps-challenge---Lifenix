// ===== PROGRAMA AstroVital - Bloque 1: lectura del MAX30102 =====

#include <Wire.h>              // Librería para comunicarse por I2C (los cables SDA y SCL)
#include "MAX30105.h"          // Librería de SparkFun que controla el sensor (sirve también para el MAX30102)
#include "spo2_algorithm.h"    // Fórmula de la librería que calcula el pulso y el oxígeno

MAX30105 sensor;               // Creamos un "objeto" llamado sensor que representa al MAX30102

const int MUESTRAS = 100;      // Cantidad de lecturas que juntamos antes de calcular (equivale a unos 4 segundos)
uint32_t bufferIR[MUESTRAS];   // Lista donde guardamos las 100 lecturas de luz infrarroja
uint32_t bufferRojo[MUESTRAS]; // Lista donde guardamos las 100 lecturas de luz roja

int32_t spo2;                  // Aquí la fórmula guardará el oxígeno en sangre (en %)
int8_t  spo2Valido;            // Vale 1 si el oxígeno calculado es confiable, 0 si no
int32_t pulso;                 // Aquí la fórmula guardará el pulso (latidos por minuto)
int8_t  pulsoValido;           // Vale 1 si el pulso calculado es confiable, 0 si no

void setup() {                 // Esta parte se ejecuta UNA sola vez al encender el ESP32
  Serial.begin(115200);        // Abrimos la comunicación con la laptop a 115200 de velocidad
  Wire.begin(21, 22);          // Iniciamos el I2C: SDA en el GPIO 21 y SCL en el GPIO 22 (según el archivo 04)

  if (!sensor.begin(Wire, I2C_SPEED_FAST)) {   // Intentamos encontrar el sensor en el bus I2C
    Serial.println("ERROR: no se encontro el MAX30102. Revisa los cables.");  // Si no lo encuentra, avisamos
    while (1);                 // Y nos quedamos detenidos aquí para no seguir con un error
  }

  Serial.println("MAX30102 detectado. Coloca el dedo sobre el sensor y no lo muevas...");  // Mensaje de éxito

  // Configuramos el sensor: brillo de luz, promedio, modo (rojo + infrarrojo), velocidad, ancho de pulso y rango
  sensor.setup(60, 4, 2, 100, 411, 4096);
}

void loop() {                  // Esta parte se repite UNA Y OTRA VEZ sin parar
  for (int i = 0; i < MUESTRAS; i++) {          // Repetimos 100 veces para juntar las lecturas
    while (sensor.available() == false) {       // Mientras el sensor no tenga una lectura nueva lista...
      sensor.check();                           // ...le preguntamos si ya tiene datos
    }
    bufferRojo[i] = sensor.getRed();            // Guardamos la lectura de luz roja
    bufferIR[i]   = sensor.getIR();             // Guardamos la lectura de luz infrarroja
    sensor.nextSample();                        // Pasamos a la siguiente lectura
  }

  if (bufferIR[MUESTRAS - 1] < 50000) {         // Si la luz infrarroja es muy baja, no hay dedo sobre el sensor
    Serial.println("Sin dedo: coloca el dedo sobre el sensor");  // Avisamos al usuario
    return;                                     // Volvemos a empezar el loop sin calcular nada
  }

  // Le damos las 200 lecturas a la fórmula y ella calcula el pulso y el oxígeno
  maxim_heart_rate_and_oxygen_saturation(bufferIR, MUESTRAS, bufferRojo,
                                         &spo2, &spo2Valido, &pulso, &pulsoValido);

  Serial.print("Pulso: ");                      // Escribimos el texto "Pulso: "
  if (pulsoValido == 1) Serial.print(pulso);    // Si el pulso es confiable, mostramos el número
  else Serial.print("--");                      // Si no, mostramos "--"
  Serial.print(" lpm  |  SpO2: ");              // lpm = latidos por minuto
  if (spo2Valido == 1) Serial.print(spo2);      // Si el oxígeno es confiable, mostramos el número
  else Serial.print("--");                      // Si no, mostramos "--"
  Serial.println(" %");                         // Terminamos la línea con el símbolo %
}
