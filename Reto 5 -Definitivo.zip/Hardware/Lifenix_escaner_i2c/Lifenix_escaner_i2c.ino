// ===== PROGRAMA Lifenix - Escáner I2C: detecta qué sensores ve el ESP32 =====

#include <Wire.h>                     // Librería para comunicarse por I2C (cables SDA y SCL)

void setup() {                        // Se ejecuta UNA sola vez al encender el ESP32
  Serial.begin(115200);               // Abrimos la comunicación con la laptop a 115200 de velocidad
  Wire.begin(21, 22);                 // Iniciamos el I2C: SDA en GPIO 21 y SCL en GPIO 22 (según el archivo 04)
  delay(1000);                        // Esperamos 1 segundo para que todo arranque bien
  Serial.println("Escaner I2C de Lifenix iniciado");  // Mensaje de inicio
}

void loop() {                         // Se repite UNA Y OTRA VEZ sin parar
  int encontrados = 0;                // Contador de sensores encontrados (empieza en cero)

  Serial.println("Buscando sensores...");             // Avisamos que empieza la búsqueda

  for (byte direccion = 1; direccion < 127; direccion++) {  // Probamos todas las direcciones posibles
    Wire.beginTransmission(direccion);                // "Tocamos la puerta" de esta dirección
    byte respuesta = Wire.endTransmission();          // Vemos si alguien respondió (0 = sí respondió)

    if (respuesta == 0) {                             // Si un sensor respondió...
      Serial.print("Encontrado en la direccion 0x");  // Escribimos el texto
      if (direccion < 16) Serial.print("0");          // Agregamos un 0 adelante si el número es pequeño
      Serial.print(direccion, HEX);                   // Mostramos la dirección en formato hexadecimal

      if (direccion == 0x57) Serial.print("  -> MAX30102 (pulso y oxigeno)");   // Nombre si es el MAX30102
      if (direccion == 0x5A) Serial.print("  -> MLX90614 (temperatura)");       // Nombre si es el MLX90614
      if (direccion == 0x68) Serial.print("  -> MPU6050 (movimiento)");         // Nombre si es el MPU6050

      Serial.println();                               // Saltamos a la siguiente línea
      encontrados++;                                  // Sumamos 1 al contador
    }
  }

  if (encontrados == 0) {                             // Si no encontramos ningún sensor...
    Serial.println("No se encontro ningun sensor. Revisa los cables.");  // Avisamos
  } else {                                            // Si encontramos al menos uno...
    Serial.print("Total de sensores encontrados: ");  // Escribimos el texto
    Serial.println(encontrados);                      // Mostramos cuántos
  }

  Serial.println("-----------------------------");    // Línea separadora para que se lea mejor
  delay(5000);                                        // Esperamos 5 segundos antes de buscar otra vez
}