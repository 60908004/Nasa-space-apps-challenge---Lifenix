// ===== PROGRAMA Lifenix - Bloque 1: lectura del MLX90614 (temperatura) =====

#include <Wire.h>                    // Librería para comunicarse por I2C (cables SDA y SCL)
#include <Adafruit_MLX90614.h>       // Librería de Adafruit que controla el sensor de temperatura

Adafruit_MLX90614 sensorTemp;        // Creamos un "objeto" llamado sensorTemp que representa al MLX90614

void setup() {                       // Se ejecuta UNA sola vez al encender el ESP32
  Serial.begin(115200);              // Abrimos la comunicación con la laptop a 115200 de velocidad
  Wire.begin(21, 22);                // Iniciamos el I2C: SDA en GPIO 21 y SCL en GPIO 22 (según el archivo 04)

  if (!sensorTemp.begin()) {         // Intentamos encontrar el sensor en la dirección 0x5A
    Serial.println("ERROR: no se encontro el MLX90614. Revisa los cables.");  // Si no lo encuentra, avisamos
    while (1);                       // Nos quedamos detenidos aquí para no seguir con un error
  }

  Serial.println("MLX90614 detectado. Acerca la frente o la muñeca al sensor (1 a 2 cm)...");  // Mensaje de éxito
}

void loop() {                        // Se repite UNA Y OTRA VEZ sin parar
  float temperatura = sensorTemp.readObjectTempC();   // Leemos la temperatura de lo que está frente al sensor (°C)
  float ambiente    = sensorTemp.readAmbientTempC();  // Leemos la temperatura del aire alrededor (°C)

  Serial.print("Temperatura: ");     // Escribimos el texto "Temperatura: "
  Serial.print(temperatura, 1);      // Mostramos la temperatura con 1 decimal (ejemplo: 36.5)
  Serial.print(" C  |  Ambiente: "); // Escribimos la unidad y el siguiente texto
  Serial.print(ambiente, 1);         // Mostramos la temperatura del ambiente con 1 decimal
  Serial.println(" C");              // Terminamos la línea con la unidad

  delay(1000);                       // Esperamos 1 segundo antes de volver a medir (como pide el archivo 03)
}