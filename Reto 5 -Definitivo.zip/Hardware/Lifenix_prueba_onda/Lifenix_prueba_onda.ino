// ===== PROGRAMA Lifenix - Prueba temporal: ver la onda del pulso en el Serial Plotter =====

#include <Wire.h>              // Librería para comunicarse por I2C (cables SDA y SCL)
#include "MAX30105.h"          // Librería de SparkFun que controla el sensor MAX30102

MAX30105 sensor;               // Creamos un "objeto" llamado sensor que representa al MAX30102

void setup() {                 // Se ejecuta UNA sola vez al encender el ESP32
  Serial.begin(115200);        // Abrimos la comunicación con la laptop a 115200 de velocidad
  Wire.begin(21, 22);          // Iniciamos el I2C: SDA en GPIO 21 y SCL en GPIO 22 (según el archivo 04)

  if (!sensor.begin(Wire, I2C_SPEED_FAST)) {   // Intentamos encontrar el sensor
    Serial.println("ERROR: no se encontro el MAX30102. Revisa los cables.");  // Si no lo encuentra, avisamos
    while (1);                 // Nos quedamos detenidos aquí
  }

  sensor.setup(30, 4, 2, 100, 411, 4096);  // La MISMA configuración del programa principal (brillo 30)
}

void loop() {                  // Se repite UNA Y OTRA VEZ sin parar
  while (sensor.available() == false) {    // Mientras no haya una lectura nueva...
    sensor.check();                        // ...le preguntamos al sensor si ya tiene datos
  }
  Serial.println(sensor.getIR());          // Enviamos la lectura de luz infrarroja (un número por línea)
  sensor.nextSample();                     // Pasamos a la siguiente lectura
}