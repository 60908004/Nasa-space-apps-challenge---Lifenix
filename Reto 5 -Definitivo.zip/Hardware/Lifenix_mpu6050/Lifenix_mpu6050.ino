// ===== PROGRAMA Lifenix - Bloque 1: lectura del MPU6050 (movimiento) SIN librería =====
// Se habla con el chip directamente por I2C, porque el módulo es un "clon"
// que la librería de Adafruit no reconoce.

#include <Wire.h>                      // Librería para comunicarse por I2C (cables SDA y SCL)

const byte DIRECCION_MPU = 0x68;       // Dirección I2C del sensor (la que vimos en el escáner)
const float LSB_POR_G = 4096.0;        // Con rango ±8 g, el sensor entrega 4096 unidades por cada 1 g

// ---- Función para escribir un valor en un "casillero" (registro) del sensor ----
void escribirRegistro(byte registro, byte valor) {
  Wire.beginTransmission(DIRECCION_MPU);  // Empezamos a hablarle al sensor
  Wire.write(registro);                   // Le decimos qué casillero queremos cambiar
  Wire.write(valor);                      // Le decimos qué valor poner en ese casillero
  Wire.endTransmission();                 // Terminamos el mensaje
}

// ---- Función para leer un casillero del sensor ----
byte leerRegistro(byte registro) {
  Wire.beginTransmission(DIRECCION_MPU);  // Empezamos a hablarle al sensor
  Wire.write(registro);                   // Le decimos qué casillero queremos leer
  Wire.endTransmission(false);            // Terminamos, pero sin "colgar" la llamada
  Wire.requestFrom(DIRECCION_MPU, (byte)1);  // Le pedimos 1 byte de respuesta
  return Wire.read();                     // Devolvemos ese byte
}

void setup() {                         // Se ejecuta UNA sola vez al encender el ESP32
  Serial.begin(115200);                // Abrimos la comunicación con la laptop a 115200 de velocidad
  Wire.begin(21, 22);                  // Iniciamos el I2C: SDA en GPIO 21 y SCL en GPIO 22 (según el archivo 04)
  delay(100);                          // Pequeña espera para que el sensor arranque

  Wire.beginTransmission(DIRECCION_MPU);       // Tocamos la puerta del sensor...
  if (Wire.endTransmission() != 0) {           // ...y si no responde...
    Serial.println("ERROR: no se encontro el MPU6050. Revisa los cables.");  // ...avisamos
    while (1);                                 // ...y nos quedamos detenidos aquí
  }

  byte identidad = leerRegistro(0x75);  // Leemos el código de identidad del chip (casillero 0x75)
  Serial.print("Codigo de identidad del chip: 0x");  // Texto
  Serial.println(identidad, HEX);       // Lo mostramos (un MPU6050 original dice 68; los clones, otro número)

  escribirRegistro(0x6B, 0x00);         // Casillero 0x6B: "despertamos" al sensor (viene dormido)
  escribirRegistro(0x1C, 0x10);         // Casillero 0x1C: rango de aceleración ±8 g (igual que antes)
  escribirRegistro(0x1A, 0x04);         // Casillero 0x1A: filtro suave para quitar "ruido" (unos 20 Hz)
  delay(100);                           // Esperamos a que tome la configuración

  Serial.println("MPU6050 detectado. Quedate quieto y luego muevete para ver el cambio...");  // Mensaje de éxito
}

void loop() {                          // Se repite UNA Y OTRA VEZ sin parar
  Wire.beginTransmission(DIRECCION_MPU);  // Empezamos a hablarle al sensor
  Wire.write(0x3B);                       // Casillero 0x3B: ahí empiezan los datos de aceleración
  Wire.endTransmission(false);            // Terminamos sin "colgar" la llamada
  Wire.requestFrom(DIRECCION_MPU, (byte)6);  // Pedimos 6 bytes: 2 para x, 2 para y, 2 para z

  int16_t crudoX = (Wire.read() << 8) | Wire.read();  // Unimos los 2 bytes de x en un número
  int16_t crudoY = (Wire.read() << 8) | Wire.read();  // Unimos los 2 bytes de y en un número
  int16_t crudoZ = (Wire.read() << 8) | Wire.read();  // Unimos los 2 bytes de z en un número

  float ax = crudoX / LSB_POR_G;          // Convertimos x a "g"
  float ay = crudoY / LSB_POR_G;          // Convertimos y a "g"
  float az = crudoZ / LSB_POR_G;          // Convertimos z a "g"

  float total = sqrt(ax * ax + ay * ay + az * az);  // Juntamos las 3 direcciones en un solo valor (en g)
  float movimiento = fabs(total - 1.0);   // Quitamos la gravedad (1 g): quieto ≈ 0, en movimiento sube

  Serial.print("Movimiento: ");           // Escribimos el texto "Movimiento: "
  Serial.print(movimiento, 2);            // Mostramos el valor con 2 decimales (ejemplo: 0.12)

  if (movimiento < 0.15) {                // Si el valor es pequeño...
    Serial.println("  -> Quieto");        // ...la persona está en reposo
  } else {                                // Si el valor es más grande...
    Serial.println("  -> En movimiento"); // ...la persona se está moviendo
  }

  delay(1000);                            // Esperamos 1 segundo antes de volver a medir (como pide el archivo 03)
}