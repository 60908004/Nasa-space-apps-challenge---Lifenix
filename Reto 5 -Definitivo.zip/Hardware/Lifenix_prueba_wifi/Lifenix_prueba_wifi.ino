// ===== PROGRAMA Lifenix - Bloque 2, prueba 1: conectar el ESP32 al WiFi local =====

#include <WiFi.h>                          // Librería del ESP32 para usar WiFi (ya viene instalada)

// ======== CAMBIAR ESTOS 2 DATOS ========
const char* RED_WIFI = "Matheu"; // Nombre de la red WiFi (debe ser de 2,4 GHz)
const char* CLAVE    = "ryuukori";  // Contraseña de la red WiFi
// =======================================

void setup() {                             // Se ejecuta UNA vez al encender
  Serial.begin(115200);                    // Comunicación con la laptop
  delay(1000);                             // Esperamos 1 segundo para que todo arranque

  WiFi.mode(WIFI_STA);                     // Modo "estación": el ESP32 se conecta a una red existente
  WiFi.begin(RED_WIFI, CLAVE);             // Intentamos conectarnos con el nombre y la clave

  Serial.print("Conectando a ");           // Texto
  Serial.print(RED_WIFI);                  // Nombre de la red
  int intentos = 0;                        // Contador de intentos (cada uno dura medio segundo)
  while (WiFi.status() != WL_CONNECTED && intentos < 40) {  // Mientras no se conecte (máximo 20 s)...
    delay(500);                            // ...esperamos medio segundo
    Serial.print(".");                     // ...y dibujamos un punto para mostrar que sigue intentando
    intentos++;                            // ...sumamos un intento
  }
  Serial.println();                        // Salto de línea

  if (WiFi.status() == WL_CONNECTED) {     // Si se conectó...
    Serial.println("WiFi CONECTADO");      // ...avisamos
    Serial.print("IP del ESP32: ");        // ...texto
    Serial.println(WiFi.localIP());        // ...mostramos su dirección IP
    Serial.print("Fuerza de la senal: ");  // ...texto
    Serial.print(WiFi.RSSI());             // ...mostramos la señal (más cerca de 0 = mejor)
    Serial.println(" dBm");                // ...unidad
  } else {                                 // Si NO se conectó...
    Serial.println("NO se pudo conectar.");                            // ...avisamos
    Serial.println("Revisa: 1) nombre y clave exactos (mayusculas),"); // ...causa 1
    Serial.println("        2) que la red sea de 2,4 GHz,");           // ...causa 2
    Serial.println("        3) que el ESP32 este cerca del router o celular."); // ...causa 3
  }
}

void loop() {                              // Se repite sin parar
  delay(5000);                             // Esperamos 5 segundos
  if (WiFi.status() == WL_CONNECTED) {     // Si sigue conectado...
    Serial.println("Sigue conectado");     // ...lo confirmamos
  } else {                                 // Si se desconectó...
    Serial.println("Desconectado. Reintentando...");  // ...avisamos
    WiFi.reconnect();                      // ...e intentamos reconectar
  }
}