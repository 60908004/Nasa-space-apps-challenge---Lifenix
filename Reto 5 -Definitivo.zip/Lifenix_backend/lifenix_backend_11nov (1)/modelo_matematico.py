# ============================================================
# LIFENIX - Modelo matematico de "linea base personal" (Nivel 3+)
# Complementa al Isolation Forest con estadistica clasica:
#   1. Calcula lo NORMAL de esta persona en reposo:
#      media (mu) y desviacion estandar (sigma) de pulso, SpO2
#      y temperatura de piel.
#   2. Para una lectura nueva calcula cuanto se aleja de lo normal:
#      z = (valor - mu) / sigma          (puntaje z de cada signo)
#      D = raiz(z_pulso^2 + z_spo2^2 + z_temp^2)   (distancia combinada)
#   3. Compara D con la distribucion chi-cuadrado de 3 grados de libertad:
#      D <= 2.80  -> dentro de lo habitual (95 % de las lecturas normales)
#      D >  3.37  -> fuera de lo habitual  (solo 1 % de las normales lo supera)
# NO es un diagnostico medico: solo mide "que tan distinto es de lo habitual".
# Uso:  python modelo_matematico.py DESDE HASTA
# Ej.:  python modelo_matematico.py 2645 4050
# Crea el archivo linea_base.json con mu y sigma de cada signo.
# ============================================================

# "json" sirve para guardar la linea base en un archivo de texto.
import json

# "math" trae la raiz cuadrada (sqrt).
import math

# "os" sirve para revisar si existe el archivo del modelo de ML.
import os

# "sqlite3" sirve para leer la base de datos (ya viene con Python).
import sqlite3

# "statistics" trae la media (mean) y la desviacion estandar (pstdev).
import statistics

# "sys" permite leer los numeros DESDE y HASTA que escribimos al ejecutar.
import sys


# Nombre del archivo de la base de datos (acordado en el documento 03).
ARCHIVO_BD = "lifenix.db"

# Archivo donde guardaremos la linea base personal.
ARCHIVO_LINEA_BASE = "linea_base.json"

# Archivo del modelo de ML (solo para comparar; si no existe, se omite).
ARCHIVO_MODELO = "modelo_lifenix.joblib"

# Temperatura minima creible de piel: por debajo, la muneca estaba lejos del sensor.
TEMPERATURA_MINIMA_PIEL = 30.0

# Limites de la distancia D, sacados de la tabla chi-cuadrado con 3 grados de libertad:
# chi2(95 %) = 7.81 -> D = raiz(7.81) = 2.80
# chi2(99 %) = 11.34 -> D = raiz(11.34) = 3.37
LIMITE_HABITUAL = 2.80
LIMITE_FUERA = 3.37

# Minimo de lecturas para que la media y la desviacion sean confiables.
MINIMO_LECTURAS = 100

# Desviacion estandar MINIMA de cada signo (piso de sigma).
# El sensor redondea (SpO2 en enteros de 97 a 100), asi que la sigma real sale
# muy chica y el modelo se vuelve demasiado sensible (SpO2 96 pareceria raro).
# Con un piso, 96 % queda como habitual y 92-94 % sigue saliendo fuera de lo habitual.
SIGMA_MINIMA = {"pulso": 5.0, "spo2": 1.5, "temperatura": 0.5}


# ---------- 0. REVISAR QUE SE ESCRIBIO EL RANGO ----------

# Si no se escribieron los dos numeros, mostramos ayuda y terminamos.
if len(sys.argv) < 3:
    # Mostramos como se usa el programa.
    print("Falta el rango. Uso:  python modelo_matematico.py DESDE HASTA")
    print("Ejemplo (sesion real de reposo del 12 nov):  python modelo_matematico.py 2645 4050")
    raise SystemExit

# Leemos los dos numeros escritos y los convertimos en enteros.
desde = int(sys.argv[1])
hasta = int(sys.argv[2])


# ---------- 1. LEER LAS LECTURAS DE REPOSO ----------

# Abrimos la base de datos.
conexion = sqlite3.connect(ARCHIVO_BD)
# Pedimos pulso, SpO2 y temperatura del rango, solo con dedo y con la muneca cerca del sensor.
filas = conexion.execute(
    "SELECT pulso, spo2, temperatura FROM lecturas "
    "WHERE id BETWEEN ? AND ? AND pulso > 0 AND spo2 > 0 AND temperatura >= ?",
    (desde, hasta, TEMPERATURA_MINIMA_PIEL),
).fetchall()
# Cerramos la base de datos.
conexion.close()

# Mostramos cuantas lecturas sirven.
print("Rango elegido: lecturas", desde, "a", hasta)
print("Lecturas validas (con dedo y piel >= 30 C):", len(filas))

# Si hay muy pocas, avisamos y terminamos.
if len(filas) < MINIMO_LECTURAS:
    print("Muy pocas lecturas (minimo", MINIMO_LECTURAS, "). Elige otro rango.")
    raise SystemExit


# ---------- 2. CALCULAR LA LINEA BASE (media y desviacion) ----------

# Nombres de los 3 signos, en el mismo orden que las columnas pedidas.
nombres = ["pulso", "spo2", "temperatura"]

# Diccionario donde guardaremos mu y sigma de cada signo.
linea_base = {}

# Recorremos cada signo con su posicion (0, 1, 2).
for posicion, nombre in enumerate(nombres):
    # Juntamos todos los valores de ese signo.
    valores = [fila[posicion] for fila in filas]
    # Media: el valor "tipico" de esta persona.
    mu = statistics.mean(valores)
    # Desviacion estandar: cuanto varia normalmente alrededor de la media.
    sigma = statistics.pstdev(valores)
    # Aplicamos el piso: la sigma nunca baja de la minima de ese signo.
    sigma = max(sigma, SIGMA_MINIMA[nombre])
    # Guardamos ambos redondeados a 3 decimales.
    linea_base[nombre] = {"mu": round(mu, 3), "sigma": round(sigma, 3)}

# Guardamos tambien el rango usado y cuantas lecturas, para saber de donde salio.
linea_base["origen"] = {"desde": desde, "hasta": hasta, "lecturas": len(filas)}

# Escribimos la linea base en el archivo JSON.
with open(ARCHIVO_LINEA_BASE, "w", encoding="utf-8") as archivo:
    json.dump(linea_base, archivo, indent=2)

# Mostramos la linea base en pantalla.
print("-" * 60)
print("LINEA BASE PERSONAL (reposo)")
print("-" * 60)
for nombre in nombres:
    # Formato: pulso: mu = 71.4  sigma = 8.1
    print(f"{nombre:12s} mu = {linea_base[nombre]['mu']:7.2f}   sigma = {linea_base[nombre]['sigma']:6.2f}")
print("Guardada en:", ARCHIVO_LINEA_BASE)


# ---------- 3. FUNCIONES DEL MODELO MATEMATICO ----------

# Funcion que calcula los 3 puntajes z y la distancia combinada D.
def distancia(pulso, spo2, temperatura):
    # Ponemos los 3 valores en una lista, en el orden de "nombres".
    valores = [pulso, spo2, temperatura]
    # Calculamos z = (valor - mu) / sigma para cada signo.
    z = [
        (valor - linea_base[nombre]["mu"]) / linea_base[nombre]["sigma"]
        for valor, nombre in zip(valores, nombres)
    ]
    # D = raiz de la suma de los z al cuadrado.
    d = math.sqrt(sum(valor_z ** 2 for valor_z in z))
    # Devolvemos los z y la distancia.
    return z, d


# Funcion que traduce D a una palabra facil de entender.
def interpretar(d):
    # Dentro del 95 % de lo habitual.
    if d <= LIMITE_HABITUAL:
        return "habitual"
    # Entre el 95 % y el 99 %: zona gris.
    if d <= LIMITE_FUERA:
        return "poco habitual"
    # Mas alla del 99 %: fuera de lo habitual para esta persona.
    return "FUERA de lo habitual"


# ---------- 4. CARGAR EL MODELO DE ML (solo para comparar) ----------

# Empezamos suponiendo que no hay modelo.
modelo = None
# Si existe el archivo del modelo, intentamos cargarlo.
if os.path.exists(ARCHIVO_MODELO):
    try:
        # joblib carga el modelo; preparar arma los 5 datos que espera.
        import joblib
        from caracteristicas import preparar
        modelo = joblib.load(ARCHIVO_MODELO)
    except Exception as error:
        # Si falla, seguimos sin comparar.
        print("No se pudo cargar el modelo de ML (se omite la comparacion):", error)


# ---------- 5. PROBAR CON CASOS DE EJEMPLO ----------

# Casos: (descripcion, pulso, spo2, temperatura de piel, movimiento).
casos = [
    ("Reposo tipico             ", 72, 98, 33.5, 0.01),
    ("REAL reposo (76,100,33.4) ", 76, 100, 33.4, 0.01),
    ("Pulso 100 en reposo       ", 100, 98, 33.5, 0.01),
    ("Pulso 130 estando quieto  ", 130, 97, 33.8, 0.01),
    ("Oxigeno bajo (SpO2 88)    ", 80, 88, 33.5, 0.01),
    ("Leve combinado (92,95,35.6)", 92, 95, 35.6, 0.01),
    ("SpO2 96 en reposo         ", 70, 96, 33.5, 0.01),
    ("SpO2 93 en reposo         ", 70, 93, 33.5, 0.01),
]

# Titulo de la prueba.
print("-" * 60)
print("PRUEBA: modelo matematico (D) vs. Isolation Forest (puntaje)")
print(f"D <= {LIMITE_HABITUAL}: habitual | D > {LIMITE_FUERA}: fuera de lo habitual")
print("-" * 60)

# Revisamos cada caso.
for descripcion, pulso, spo2, temperatura, movimiento in casos:
    # Calculamos los z y la distancia D.
    z, d = distancia(pulso, spo2, temperatura)
    # Texto con los 3 puntajes z redondeados.
    texto_z = "z=(" + ", ".join(f"{valor:+.1f}" for valor in z) + ")"
    # Texto del modelo de ML, si esta disponible.
    texto_ml = ""
    if modelo is not None:
        # Puntaje del Isolation Forest (negativo = raro).
        puntaje = modelo.decision_function([preparar(pulso, spo2, temperatura, movimiento)])[0]
        texto_ml = f"| IF: {puntaje:+.3f}"
    # Mostramos todo en una linea.
    print(f"{descripcion} {texto_z}  D={d:5.2f} -> {interpretar(d):20s} {texto_ml}")
