# ============================================================
# LIFENIX - Preparacion de datos para el modelo (Nivel 3)
# La usan entrenar_modelo.py y main.py, para que los dos
# calculen EXACTAMENTE los mismos datos.
# Ajustada al movimiento REAL del ESP32 (en g): 0.01 a 0.49.
# ============================================================

# Nombres de los 5 datos que mira el modelo, en este mismo orden.
COLUMNAS_MODELO = ["pulso", "spo2", "temperatura", "movimiento", "pulso_por_movimiento"]

# Numero que se suma al movimiento para no dividir entre 0.
# PROVISIONAL: 0.1 porque el movimiento real es pequeno (0.01-0.49).
# Si se cambia, HAY QUE VOLVER A ENTRENAR el modelo.
SUMA_MOVIMIENTO = 0.1


# Funcion que convierte una lectura (4 datos) en los 5 datos del modelo.
def preparar(pulso, spo2, temperatura, movimiento):
    # Por seguridad, si llega un movimiento negativo lo tratamos como 0.
    movimiento = max(movimiento, 0)
    # Dato nuevo: pulso dividido entre (movimiento + 0.1).
    # Reposo -> ~480 | Ejercicio -> ~325 | Pulso alto estando quieto -> ~867 (raro).
    pulso_por_movimiento = pulso / (movimiento + SUMA_MOVIMIENTO)
    # Devolvemos los 5 datos en el orden de COLUMNAS_MODELO.
    return [pulso, spo2, temperatura, movimiento, pulso_por_movimiento]