# ============================================================
# LIFENIX - Entrenamiento del modelo (Nivel 3)
# Entrena SOLO con el rango de lecturas que elijas, para usar
# unicamente situaciones normales (reposo, caminata, ejercicio).
# Uso:  python entrenar_modelo.py DESDE HASTA
# Ej.:  python entrenar_modelo.py 1000 1400
# Despues de entrenar, REINICIA la API para que use el modelo nuevo.
# ============================================================

# "sqlite3" sirve para leer la base de datos (ya viene con Python).
import sqlite3

# "sys" permite leer los numeros que escribimos al ejecutar (DESDE y HASTA).
import sys

# "joblib" sirve para guardar el modelo entrenado en un archivo.
import joblib

# Importamos el algoritmo Isolation Forest de scikit-learn.
from sklearn.ensemble import IsolationForest

# Importamos nuestra "receta" que convierte 4 datos en 5.
from caracteristicas import preparar


# Nombre del archivo de la base de datos (acordado en el documento 03).
ARCHIVO_BD = "lifenix.db"

# Nombre del archivo donde guardaremos el modelo entrenado.
ARCHIVO_MODELO = "modelo_lifenix.joblib"

# Porcentaje de lecturas que esperamos que sean "raras" (2 %).
CONTAMINACION = 0.02

# Minimo de lecturas necesarias para entrenar con confianza.
MINIMO_LECTURAS = 100

# Oxigeno por debajo de este valor NO deberia estar en datos "normales".
SPO2_MINIMO_NORMAL = 92


# ---------- 0. REVISAR QUE SE ESCRIBIO EL RANGO ----------

# Si no se escribieron los dos numeros, mostramos ayuda y terminamos.
if len(sys.argv) < 3:
    # Abrimos la base para mostrar un resumen util.
    conexion = sqlite3.connect(ARCHIVO_BD)
    # Pedimos el primer id, el ultimo id y el total de lecturas.
    primero, ultimo, total = conexion.execute(
        "SELECT MIN(id), MAX(id), COUNT(*) FROM lecturas"
    ).fetchone()
    # Cerramos la base.
    conexion.close()
    # Mostramos el resumen y la forma correcta de usar el programa.
    print("Lecturas en la base:", total, "| desde la", primero, "hasta la", ultimo)
    print("Falta el rango. Uso:  python entrenar_modelo.py DESDE HASTA")
    print("Ejemplo:              python entrenar_modelo.py 1000 1400")
    raise SystemExit

# Leemos los dos numeros escritos y los convertimos en enteros.
desde = int(sys.argv[1])
hasta = int(sys.argv[2])

# ---------- 1. LEER LOS DATOS DEL RANGO ----------

# Abrimos la base de datos.
conexion = sqlite3.connect(ARCHIVO_BD)
# Pedimos los 4 datos de cada lectura del rango,
# sin las de prueba ("sin_evaluar") ni las sin dedo ("sin_dato").
filas = conexion.execute(
    "SELECT pulso, spo2, temperatura, movimiento FROM lecturas "
    "WHERE id BETWEEN ? AND ? AND estado NOT IN ('sin_evaluar', 'sin_dato') "
    "AND pulso > 0 AND spo2 > 0",
    (desde, hasta),
).fetchall()
# Cerramos la base de datos.
conexion.close()

# Mostramos el rango y cuantas lecturas encontramos.
print("Rango elegido: lecturas", desde, "a", hasta)
print("Lecturas encontradas para entrenar:", len(filas))

# Si hay muy pocas, avisamos y terminamos el programa.
if len(filas) < MINIMO_LECTURAS:
    print("Muy pocas lecturas (minimo", MINIMO_LECTURAS, "). Elige un rango mas grande.")
    raise SystemExit

# Contamos cuantas lecturas del rango tienen oxigeno bajo (no deberian estar).
oxigeno_bajo = sum(1 for fila in filas if fila[1] < SPO2_MINIMO_NORMAL)
# Si hay alguna, avisamos para que el usuario revise el rango.
if oxigeno_bajo > 0:
    print("AVISO:", oxigeno_bajo, "lecturas con oxigeno bajo en este rango.")
    print("       Si no son errores del sensor, elige otro rango sin alertas.")

# Preparamos cada fila con la receta: de 4 datos pasamos a 5.
datos = [preparar(*fila) for fila in filas]

# ---------- 2. ENTRENAR EL MODELO ----------

# Creamos el modelo con sus ajustes.
modelo = IsolationForest(
    n_estimators=200,             # cantidad de "arbolitos" que votan
    contamination=CONTAMINACION,  # porcentaje esperado de lecturas raras
    random_state=42,              # para que el resultado sea siempre igual
)
# Entrenamos: el modelo aprende como se ven las lecturas normales.
modelo.fit(datos)
# Avisamos que termino.
print("Modelo entrenado.")

# ---------- 3. GUARDAR EL MODELO ----------

# Guardamos el modelo entrenado en un archivo.
joblib.dump(modelo, ARCHIVO_MODELO)
# Avisamos donde quedo guardado y recordamos reiniciar la API.
print("Modelo guardado en:", ARCHIVO_MODELO)
print("RECUERDA: reinicia la API (Ctrl + C y volver a encender) para usar este modelo.")

# ---------- 4. PROBAR CON CASOS DE EJEMPLO ----------

# Casos: (descripcion, pulso, spo2, temperatura de piel, movimiento real en g).
# Los 3 ultimos son lecturas REALES del ESP32 (revision de [HW], 10 nov).
casos = [
    ("Reposo tranquilo          ", 72, 98, 33.5, 0.05),
    ("Sentadillas (ejercicio)   ", 130, 97, 34.5, 0.30),
    ("Pulso alto estando quieto ", 130, 97, 33.8, 0.05),
    ("Oxigeno bajo en reposo    ", 80, 88, 33.5, 0.05),
    ("REAL reposo (76,100,33.4) ", 76, 100, 33.4, 0.01),
    ("REAL reposo (78,99,34.8)  ", 78, 99, 34.8, 0.03),
    ("REAL movimiento (110,0.40)", 110, 98, 33.5, 0.40),
]

# Mostramos un titulo para la prueba.
print("-" * 60)
print("PRUEBA DEL MODELO (1 = normal, -1 = anomalia)")
print("-" * 60)

# Revisamos cada caso uno por uno.
for descripcion, pulso, spo2, temperatura, movimiento in casos:
    # Preparamos el caso con la misma receta (5 datos).
    valores = preparar(pulso, spo2, temperatura, movimiento)
    # El modelo responde 1 (normal) o -1 (anomalia).
    resultado = modelo.predict([valores])[0]
    # Puntaje: mientras mas negativo, mas raro le parece.
    puntaje = modelo.decision_function([valores])[0]
    # Convertimos el resultado en una palabra facil de leer.
    texto = "NORMAL" if resultado == 1 else "ANOMALIA"
    # Mostramos el caso, el resultado y el puntaje con 3 decimales.
    print(descripcion, "->", texto, "(puntaje:", round(puntaje, 3), ")")