# ============================================================
# LIFENIX - API completa (ajustada a sensores reales, 10 nov)
# - Lecturas de sensores: reglas fijas + modelo ML + estado_final
# - El ROJO lo deciden las reglas; el modelo solo agrega amarillo
#   o quita falsas alarmas cuando hay ejercicio.
# - "sin_dato" cuando el MAX30102 envia 0 (no hay dedo)
# - Registro manual: horas de sueno y estado de animo
# Todo se guarda en SQLite (lifenix.db).
# ============================================================

# "os" sirve para revisar si existe el archivo del modelo.
import os

# Importamos "sqlite3", que ya viene con Python, para usar la base de datos.
import sqlite3

# Importamos "datetime" para anotar la fecha y hora de cada registro.
from datetime import datetime

# "joblib" sirve para cargar el modelo entrenado desde su archivo.
import joblib

# Importamos FastAPI, la herramienta para crear la API.
from fastapi import FastAPI

# BaseModel define la "forma" de los datos; Field pone limites (minimo, maximo).
from pydantic import BaseModel, Field

# Importamos la "receta" que convierte 4 datos en los 5 del modelo.
from caracteristicas import preparar


# Nombre del archivo de la base de datos (acordado en el documento 03).
ARCHIVO_BD = "lifenix.db"

# Nombre del archivo del modelo entrenado (creado por entrenar_modelo.py).
ARCHIVO_MODELO = "modelo_lifenix.joblib"

# ------------------------------------------------------------
# LIMITES DEL SEMAFORO (se pueden ajustar aqui facilmente)
# Para cada indicador: rango "normal" (verde) y rango "atencion" (amarillo).
# Todo lo que quede fuera del rango de atencion es "alerta" (rojo).
# Son valores generales de apoyo, NO un diagnostico medico.
# ------------------------------------------------------------
UMBRALES = {
    # Pulso en latidos por minuto.
    "pulso": {"normal": (60, 100), "atencion": (50, 120)},
    # Oxigeno en sangre en porcentaje.
    "spo2": {"normal": (95, 100), "atencion": (92, 100)},
    # Temperatura de la PIEL (MLX90614 en la muneca), en grados Celsius.
    # Valores reales medidos: 31-35 C. Ajustar con mas pruebas.
    "temperatura": {"normal": (32.0, 36.0), "atencion": (30.0, 37.0)},
}

# Movimiento a partir del cual consideramos que la persona hace ejercicio.
# PROVISIONAL: ESP32 real quieto ~0.01-0.10, moviendose ~0.16-0.49.
# Ajustar midiendo sentadillas reales con el sensor puesto.
MOVIMIENTO_EJERCICIO = 0.15

# Creamos la aplicacion (la API) y le ponemos un titulo.
app = FastAPI(title="LIFENIX API")

# Importamos el permiso CORS de FastAPI (sirve para que el tablero web pueda hablar con la API).
from fastapi.middleware.cors import CORSMiddleware

# Activamos CORS: el navegador deja que el tablero lea y envie datos a esta API.
# Se permite "todo" (*) porque el sistema funciona solo en la red local, sin internet.
app.add_middleware(
    CORSMiddleware,          # El permiso que estamos agregando
    allow_origins=["*"],     # Cualquier pagina (el tablero) puede conectarse
    allow_methods=["*"],     # Se permiten todos los tipos de pedido (GET, POST, etc.)
    allow_headers=["*"],     # Se permiten todas las cabeceras (por ejemplo, Content-Type)
)


# Definimos la forma del mensaje que envia el ESP32.
# Si llega un dato con otro nombre o tipo, FastAPI lo rechaza solo.
class Lectura(BaseModel):
    pulso: float        # latidos por minuto, ejemplo: 78 (0 = sin dedo)
    spo2: float         # oxigeno en sangre en %, ejemplo: 97 (0 = sin dedo)
    temperatura: float  # grados Celsius (piel), ejemplo: 33.5
    movimiento: float   # intensidad del movimiento en g, ejemplo: 0.05


# Definimos la forma del registro manual que envia el tablero.
class RegistroManual(BaseModel):
    # Horas dormidas: entre 0 y 24, ejemplo: 6.5
    horas_sueno: float = Field(ge=0, le=24)
    # Animo de 1 a 5: 1 muy mal, 2 mal, 3 regular, 4 bien, 5 muy bien.
    animo: int = Field(ge=1, le=5)
    # Comentario opcional del astronauta (maximo 200 letras).
    comentario: str = Field(default="", max_length=200)


# ---------- REGLAS FIJAS (Nivel 2) ----------

# Funcion que dice si el MAX30102 tiene un dedo puesto.
def hay_dedo(lectura):
    # El ESP32 envia pulso 0 o spo2 0 cuando no hay dedo (o al arrancar).
    return lectura.pulso > 0 and lectura.spo2 > 0


# Funcion que califica UN valor segun sus limites.
def evaluar_valor(valor, limites):
    # Separamos el rango normal en minimo y maximo.
    normal_min, normal_max = limites["normal"]
    # Separamos el rango de atencion en minimo y maximo.
    atencion_min, atencion_max = limites["atencion"]
    # Si el valor esta dentro del rango normal, es verde.
    if normal_min <= valor <= normal_max:
        return "normal"
    # Si no, pero esta dentro del rango de atencion, es amarillo.
    if atencion_min <= valor <= atencion_max:
        return "atencion"
    # Si esta fuera de ambos rangos, es rojo.
    return "alerta"


# Funcion que elige el peor estado de una lista (alerta > atencion > normal).
def peor_estado(estados):
    # Si alguno es "alerta", el resultado es "alerta".
    if "alerta" in estados:
        return "alerta"
    # Si no hay alertas pero alguno es "atencion", el resultado es "atencion".
    if "atencion" in estados:
        return "atencion"
    # Si todos estan bien, el resultado es "normal".
    return "normal"


# Funcion que califica la lectura completa de los sensores.
def evaluar_estado(lectura):
    # Sin dedo no se puede evaluar: devolvemos "sin_dato".
    if not hay_dedo(lectura):
        return "sin_dato"
    # Calificamos cada indicador por separado y nos quedamos con el peor.
    return peor_estado([
        evaluar_valor(lectura.pulso, UMBRALES["pulso"]),
        evaluar_valor(lectura.spo2, UMBRALES["spo2"]),
        evaluar_valor(lectura.temperatura, UMBRALES["temperatura"]),
    ])


# ---------- MODELO ML (Nivel 3) ----------

# Funcion que carga el modelo entrenado, si existe.
def cargar_modelo():
    # Si el archivo no existe, avisamos y seguimos solo con reglas (plan B).
    if not os.path.exists(ARCHIVO_MODELO):
        print("Sin modelo ML: se usan solo las reglas fijas (plan B).")
        return None
    try:
        # Intentamos cargar el modelo desde el archivo.
        modelo_cargado = joblib.load(ARCHIVO_MODELO)
        # Avisamos que se cargo bien.
        print("Modelo ML cargado:", ARCHIVO_MODELO)
        return modelo_cargado
    except Exception as error:
        # Si falla, avisamos y seguimos solo con reglas (plan B).
        print("No se pudo cargar el modelo ML (plan B, solo reglas):", error)
        return None


# Cargamos el modelo una sola vez, al encender la API.
modelo = cargar_modelo()


# Funcion que pide la opinion del modelo sobre una lectura.
def evaluar_ml(lectura):
    # Si no hay modelo o no hay dedo, no hay opinion (None = "sin dato").
    if modelo is None or not hay_dedo(lectura):
        return None, None
    # Preparamos los 5 datos con la misma receta del entrenamiento.
    valores = preparar(lectura.pulso, lectura.spo2, lectura.temperatura, lectura.movimiento)
    # Puntaje del modelo: positivo = normal, negativo = raro.
    puntaje = float(modelo.decision_function([valores])[0])
    # El modelo responde -1 si es anomalia; lo guardamos como 1 (si) o 0 (no).
    anomalia = 1 if modelo.predict([valores])[0] == -1 else 0
    # Convertimos el puntaje en un indice de riesgo de 0 a 100.
    # (puntaje 0 -> riesgo 50; mas negativo -> mas riesgo)
    riesgo = round(min(100, max(0, 50 - puntaje * 500)))
    # Devolvemos las dos opiniones.
    return anomalia, riesgo


# Funcion que decide el color final combinando reglas y modelo.
# Idea: el ROJO lo deciden las reglas; el modelo agrega amarillo (prudencia)
# o quita falsas alarmas cuando hay ejercicio.
def decidir_estado_final(lectura, estado, anomalia):
    # 0. Sin dedo: el color final tambien es "sin_dato" (gris en el tablero).
    if estado == "sin_dato":
        return "sin_dato"
    # 1. Si no hay modelo, el color final es el de las reglas (plan B).
    if anomalia is None:
        return estado
    # 2. Seguridad: oxigeno por debajo del limite de atencion SIEMPRE es alerta.
    if lectura.spo2 < UMBRALES["spo2"]["atencion"][0]:
        return "alerta"
    # Anotamos si hay evidencia de ejercicio (movimiento alto).
    hay_ejercicio = lectura.movimiento >= MOVIMIENTO_EJERCICIO
    # 3. Reglas en rojo con la persona QUIETA: siempre alerta.
    if estado == "alerta" and not hay_ejercicio:
        return "alerta"
    # 4. Reglas marcan algo, hay ejercicio y el modelo dice normal:
    #    falsa alarma corregida -> amarillo ("parece ejercicio, vigila").
    if estado in ("alerta", "atencion") and hay_ejercicio and anomalia == 0:
        return "atencion"
    # 5. El modelo ve algo raro:
    #    si las reglas ya estaban en rojo -> rojo; si no -> amarillo ("repite la medicion").
    if anomalia == 1:
        return "alerta" if estado == "alerta" else "atencion"
    # 6. Si las reglas marcan amarillo, se respeta.
    if estado == "atencion":
        return "atencion"
    # 7. Si todo esta bien, es verde.
    return "normal"


# ---------- REGISTRO MANUAL (sueno y animo) ----------

# Funcion que califica el registro manual y arma una recomendacion.
# Recomendaciones generales y prudentes: NO es un diagnostico medico.
def evaluar_registro_manual(registro):
    # Lista de estados (uno por indicador) y lista de recomendaciones.
    estados = []
    recomendaciones = []

    # --- Horas de sueno ---
    if registro.horas_sueno < 5:
        # Muy poco sueno: alerta.
        estados.append("alerta")
        recomendaciones.append(
            "Dormiste muy poco. Prioriza tu proximo periodo de descanso y evita "
            "tareas criticas si sientes somnolencia. Si se repite, avisa al medico de vuelo."
        )
    elif registro.horas_sueno < 7:
        # Algo de falta de sueno: atencion.
        estados.append("atencion")
        recomendaciones.append(
            "Dormiste menos de lo recomendado (7 a 9 horas). Intenta respetar tu "
            "horario de descanso y reducir la luz de pantallas antes de dormir."
        )
    elif registro.horas_sueno > 10:
        # Mucho mas sueno de lo habitual: atencion.
        estados.append("atencion")
        recomendaciones.append(
            "Dormiste mas de lo habitual. Si te sientes cansado sin motivo, "
            "comentalo con el medico de vuelo."
        )
    else:
        # Sueno adecuado: normal.
        estados.append("normal")

    # --- Estado de animo ---
    if registro.animo <= 2:
        # Animo bajo: atencion.
        estados.append("atencion")
        recomendaciones.append(
            "Tu animo esta bajo. Conversa con un companero de tripulacion o con el "
            "equipo de apoyo psicologico en Tierra. No tienes que manejarlo solo."
        )
    else:
        # Animo regular o bueno: normal.
        estados.append("normal")

    # Si no hubo ninguna recomendacion, damos un mensaje positivo.
    if not recomendaciones:
        recomendaciones.append(
            "Todo bien. Sigue con tu rutina de descanso y mantente en contacto con tu tripulacion."
        )

    # Devolvemos el peor estado y las recomendaciones unidas en un solo texto.
    return peor_estado(estados), " ".join(recomendaciones)


# ---------- BASE DE DATOS ----------

# Funcion que abre una conexion con la base de datos.
def conectar():
    # Abrimos (o creamos, si no existe) el archivo lifenix.db.
    conexion = sqlite3.connect(ARCHIVO_BD)
    # Pedimos que cada fila se pueda leer por nombre de columna.
    conexion.row_factory = sqlite3.Row
    # Entregamos la conexion lista para usar.
    return conexion


# Funcion que agrega una columna a la tabla "lecturas", solo si todavia no existe.
def agregar_columna_si_falta(conexion, nombre, tipo):
    # Pedimos la lista de columnas que ya tiene la tabla "lecturas".
    columnas = [fila[1] for fila in conexion.execute("PRAGMA table_info(lecturas)")]
    # Si la columna no esta, la agregamos (las lecturas viejas quedan vacias).
    if nombre not in columnas:
        conexion.execute(f"ALTER TABLE lecturas ADD COLUMN {nombre} {tipo}")


# Funcion que crea las tablas y columnas que falten.
def crear_tabla():
    # Abrimos la conexion.
    conexion = conectar()
    # Tabla de lecturas de sensores (acordada en el documento 03).
    conexion.execute("""
        CREATE TABLE IF NOT EXISTS lecturas (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            fecha_hora TEXT,
            pulso REAL,
            spo2 REAL,
            temperatura REAL,
            movimiento REAL,
            estado TEXT
        )
    """)
    # Columnas del modelo ML (sin borrar nada).
    agregar_columna_si_falta(conexion, "anomalia", "INTEGER")
    agregar_columna_si_falta(conexion, "riesgo", "REAL")
    agregar_columna_si_falta(conexion, "estado_final", "TEXT")
    # Tabla de registros manuales (sueno y animo).
    conexion.execute("""
        CREATE TABLE IF NOT EXISTS registros_manuales (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            fecha_hora TEXT,
            horas_sueno REAL,
            animo INTEGER,
            comentario TEXT,
            estado TEXT,
            recomendacion TEXT
        )
    """)
    # Confirmamos (guardamos) los cambios.
    conexion.commit()
    # Cerramos la conexion.
    conexion.close()


# Al encender la API, nos aseguramos de que las tablas y columnas existan.
crear_tabla()


# ---------- RUTAS DE LA API ----------

# Ruta de prueba: al abrir la direccion principal, responde un saludo.
@app.get("/")
def inicio():
    # Devolvemos un mensaje y si el modelo ML esta activo.
    return {"mensaje": "LIFENIX API funcionando", "modelo_ml": modelo is not None}


# Ruta POST /lecturas: aqui el ESP32 envia cada lectura.
@app.post("/lecturas")
def recibir_lectura(lectura: Lectura):
    # Anotamos la fecha y hora actual, en texto.
    fecha_hora = datetime.now().isoformat(timespec="seconds")
    # Opinion de las reglas fijas.
    estado = evaluar_estado(lectura)
    # Opinion del modelo ML.
    anomalia, riesgo = evaluar_ml(lectura)
    # Decision final combinando ambas.
    estado_final = decidir_estado_final(lectura, estado, anomalia)
    # Abrimos la conexion con la base de datos.
    conexion = conectar()
    # Insertamos una fila nueva con todos los datos.
    cursor = conexion.execute(
        "INSERT INTO lecturas (fecha_hora, pulso, spo2, temperatura, movimiento, "
        "estado, anomalia, riesgo, estado_final) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)",
        (fecha_hora, lectura.pulso, lectura.spo2, lectura.temperatura, lectura.movimiento,
         estado, anomalia, riesgo, estado_final),
    )
    # Guardamos el cambio en el archivo.
    conexion.commit()
    # Obtenemos el numero (id) que SQLite le asigno a la fila.
    nuevo_id = cursor.lastrowid
    # Cerramos la conexion.
    conexion.close()
    # Mostramos en la terminal lo que llego y las dos opiniones.
    print("Lectura", nuevo_id, "| reglas:", estado.upper(), "| ML anomalia:", anomalia,
          "riesgo:", riesgo, "| FINAL:", estado_final.upper(), lectura.model_dump())
    # Respondemos con todo lo calculado.
    return {"ok": True, "id": nuevo_id, "estado": estado, "anomalia": anomalia,
            "riesgo": riesgo, "estado_final": estado_final}


# Ruta GET /lecturas/ultimas: devuelve las ultimas lecturas guardadas.
@app.get("/lecturas/ultimas")
def ultimas_lecturas(cantidad: int = 20):
    # Abrimos la conexion con la base de datos.
    conexion = conectar()
    # Pedimos las ultimas "cantidad" filas, de la mas nueva a la mas vieja.
    filas = conexion.execute(
        "SELECT * FROM lecturas ORDER BY id DESC LIMIT ?",
        (cantidad,),
    ).fetchall()
    # Cerramos la conexion.
    conexion.close()
    # Convertimos cada fila en diccionario y las ordenamos de vieja a nueva
    # (asi el tablero puede dibujar el grafico de izquierda a derecha).
    return [dict(fila) for fila in reversed(filas)]


# Ruta POST /registro_manual: el tablero envia horas de sueno y animo.
@app.post("/registro_manual")
def guardar_registro_manual(registro: RegistroManual):
    # Anotamos la fecha y hora actual, en texto.
    fecha_hora = datetime.now().isoformat(timespec="seconds")
    # Calificamos el registro y armamos la recomendacion.
    estado, recomendacion = evaluar_registro_manual(registro)
    # Abrimos la conexion con la base de datos.
    conexion = conectar()
    # Insertamos una fila nueva en la tabla de registros manuales.
    cursor = conexion.execute(
        "INSERT INTO registros_manuales (fecha_hora, horas_sueno, animo, comentario, "
        "estado, recomendacion) VALUES (?, ?, ?, ?, ?, ?)",
        (fecha_hora, registro.horas_sueno, registro.animo, registro.comentario,
         estado, recomendacion),
    )
    # Guardamos el cambio en el archivo.
    conexion.commit()
    # Obtenemos el numero (id) del registro.
    nuevo_id = cursor.lastrowid
    # Cerramos la conexion.
    conexion.close()
    # Mostramos en la terminal lo que llego.
    print("Registro manual", nuevo_id, "|", estado.upper(), registro.model_dump())
    # Respondemos al tablero con el estado y la recomendacion.
    return {"ok": True, "id": nuevo_id, "estado": estado, "recomendacion": recomendacion}


# Ruta GET /registro_manual/ultimos: devuelve los ultimos registros manuales.
@app.get("/registro_manual/ultimos")
def ultimos_registros_manuales(cantidad: int = 7):
    # Abrimos la conexion con la base de datos.
    conexion = conectar()
    # Pedimos los ultimos "cantidad" registros, del mas nuevo al mas viejo.
    filas = conexion.execute(
        "SELECT * FROM registros_manuales ORDER BY id DESC LIMIT ?",
        (cantidad,),
    ).fetchall()
    # Cerramos la conexion.
    conexion.close()
    # Los devolvemos ordenados del mas viejo al mas nuevo.
    return [dict(fila) for fila in reversed(filas)]