# ============================================================
# LIFENIX - Simulador de lecturas (Plan B)
# Finge ser el ESP32: envia una lectura inventada cada segundo
# a la API (POST /lecturas). Rangos ajustados a los valores
# REALES medidos por [HW] el 10 nov (temperatura de piel,
# movimiento en g).
# Uso:  python simulador.py reposo
#       python simulador.py ejercicio
#       python simulador.py alerta
#       python simulador.py sindedo
# Para detenerlo: Ctrl + C
# ============================================================

# "json" convierte los datos al formato de texto que entiende la API.
import json

# "random" sirve para inventar numeros al azar.
import random

# "sys" permite leer la palabra que escribimos al ejecutar (el modo).
import sys

# "time" sirve para esperar 1 segundo entre envios.
import time

# "urllib.request" permite enviar datos a la API (ya viene con Python).
import urllib.request


# Direccion de la API que recibe las lecturas (acordada en el documento 03).
URL_API = "http://127.0.0.1:8000/lecturas"

# Cada cuantos segundos se envia una lectura (igual que el ESP32).
SEGUNDOS_ENTRE_ENVIOS = 1


# Funcion que inventa una lectura segun el modo elegido.
def inventar_lectura(modo):
    # Modo "ejercicio": sentadillas -> pulso alto y movimiento alto.
    if modo == "ejercicio":
        pulso = random.uniform(115, 140)          # pulso alto por el esfuerzo
        spo2 = random.uniform(95, 99)             # oxigeno normal
        temperatura = random.uniform(33.0, 35.5)  # piel un poco mas caliente
        movimiento = random.uniform(0.16, 0.49)   # movimiento real "fuerte"
    # Modo "alerta": sentado, pero con oxigeno bajo (alerta real).
    elif modo == "alerta":
        pulso = random.uniform(95, 110)           # pulso algo elevado
        spo2 = random.uniform(86, 90)             # oxigeno bajo
        temperatura = random.uniform(33.0, 35.0)  # piel normal
        movimiento = random.uniform(0.01, 0.10)   # casi sin movimiento
    # Modo "sindedo": el MAX30102 no tiene dedo -> envia pulso 0 y spo2 0.
    elif modo == "sindedo":
        pulso = 0                                 # sin dedo
        spo2 = 0                                  # sin dedo
        temperatura = random.uniform(33.0, 34.0)  # la temperatura si se mide
        movimiento = random.uniform(0.01, 0.10)   # casi sin movimiento
    # Modo "reposo" (o cualquier otra palabra): todo normal.
    else:
        pulso = random.uniform(65, 80)            # pulso tranquilo
        spo2 = random.uniform(96, 100)            # oxigeno normal
        temperatura = random.uniform(32.5, 35.0)  # piel normal
        movimiento = random.uniform(0.01, 0.03)   # casi sin movimiento

    # Devolvemos la lectura con el formato acordado y numeros redondeados.
    return {
        "pulso": round(pulso),                  # sin decimales, ej: 72
        "spo2": round(spo2),                    # sin decimales, ej: 97
        "temperatura": round(temperatura, 1),   # 1 decimal, ej: 33.5
        "movimiento": round(movimiento, 2),     # 2 decimales, ej: 0.05
    }


# Funcion que envia una lectura a la API y devuelve su respuesta.
def enviar_lectura(lectura):
    # Convertimos la lectura a texto JSON y luego a bytes.
    datos = json.dumps(lectura).encode("utf-8")
    # Preparamos el envio tipo POST, avisando que mandamos JSON.
    peticion = urllib.request.Request(
        URL_API,
        data=datos,
        headers={"Content-Type": "application/json"},
        method="POST",
    )
    # Enviamos y esperamos la respuesta (maximo 5 segundos).
    with urllib.request.urlopen(peticion, timeout=5) as respuesta:
        # Leemos la respuesta de la API y la convertimos a diccionario.
        return json.loads(respuesta.read().decode("utf-8"))


# Leemos el modo escrito al ejecutar; si no se escribio nada, usamos "reposo".
modo = sys.argv[1] if len(sys.argv) > 1 else "reposo"

# Mostramos en pantalla como arranca el simulador.
print("Simulador LIFENIX en modo:", modo.upper())
print("Enviando a:", URL_API)
print("Para detenerlo presiona Ctrl + C")
print("-" * 60)

# Repetimos para siempre (hasta que presionemos Ctrl + C).
try:
    while True:
        # Inventamos una lectura nueva.
        lectura = inventar_lectura(modo)
        try:
            # Intentamos enviarla a la API.
            respuesta = enviar_lectura(lectura)
            # Mostramos lo enviado y el estado FINAL que calculo la API.
            print("Enviado:", lectura, "-> final:", respuesta.get("estado_final"),
                  "| reglas:", respuesta.get("estado"), "| riesgo:", respuesta.get("riesgo"))
        except Exception as error:
            # Si la API esta apagada o falla, avisamos pero no nos detenemos.
            print("No se pudo enviar (la API esta encendida?):", error)
        # Esperamos antes del siguiente envio.
        time.sleep(SEGUNDOS_ENTRE_ENVIOS)
except KeyboardInterrupt:
    # Al presionar Ctrl + C, salimos de forma ordenada.
    print("\nSimulador detenido.")